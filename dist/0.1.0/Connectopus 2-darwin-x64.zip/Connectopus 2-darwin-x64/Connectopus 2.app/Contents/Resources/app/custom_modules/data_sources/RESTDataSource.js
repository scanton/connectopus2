module.exports = class RESTDataSource extends AbstractDataSource {

	constructor(type, con) {
		super(type, con);
	}
}