module.exports = class JSONDataSource extends AbstractDataSource {

	constructor(type, con) {
		super(type, con);
	}
}