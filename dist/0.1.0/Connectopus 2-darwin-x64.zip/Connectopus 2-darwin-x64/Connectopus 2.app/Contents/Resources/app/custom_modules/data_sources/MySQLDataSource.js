module.exports = class MySQLDataSource extends AbstractDataSource {

	constructor(type, con) {
		super(type, con);
	}
}